#!/bin/zsh
cd "$(dirname "$0")"
python3 launcher.py
