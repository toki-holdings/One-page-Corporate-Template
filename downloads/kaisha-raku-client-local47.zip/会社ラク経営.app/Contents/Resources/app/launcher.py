import contextlib
import hashlib
import http.server
import json
import os
import re
import socket
import socketserver
import subprocess
import sys
import threading
import time
import secrets
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from urllib.parse import urlsplit


APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
START_PORT = 8787
URL_FILE_ARG = "--url-file="
SUPABASE_PROXY_PREFIX = "/__supabase"
LAUNCHER_CONTROL_PREFIX = "/__kaisha"
START_PORT_ENV = "KAISHA_RAKU_START_PORT"
PROXY_COOKIE_NAME = "kaisha_raku_proxy_token"
INSTANCE_DIR = Path.home() / "Library" / "Application Support" / "KaishaRakuKeiei"
APP_VERSION = "20261011-local47"
UPDATE_MANIFEST_URL = os.environ.get("KAISHA_RAKU_UPDATE_MANIFEST") or "https://toki-holdings.jp/app/latest.json"
UPDATE_DISABLE_ENV = "KAISHA_RAKU_DISABLE_UPDATE"
UPDATE_TIMEOUT_SECONDS = 8
PAGE_CLOSE_GRACE_SECONDS = 6
MONITOR_INTERVAL_SECONDS = 1


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        origin = self.headers.get("Origin") or ""
        if origin and self.is_allowed_origin(origin):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Headers", "apikey, authorization, content-type, prefer")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
            self.send_header("Vary", "Origin")
        self.send_header("Set-Cookie", f"{PROXY_COOKIE_NAME}={self.server.proxy_token}; Path=/; SameSite=Strict; HttpOnly")
        super().end_headers()

    def log_message(self, format, *args):
        return

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith(LAUNCHER_CONTROL_PREFIX):
            self.handle_launcher_control()
            return
        if self.path.startswith(SUPABASE_PROXY_PREFIX):
            self.handle_supabase_proxy()
            return
        super().do_GET()

    def do_POST(self):
        if self.path.startswith(LAUNCHER_CONTROL_PREFIX):
            self.handle_launcher_control()
            return
        if self.path.startswith(SUPABASE_PROXY_PREFIX):
            self.handle_supabase_proxy()
            return
        self.send_error(404)

    def do_PATCH(self):
        if self.path.startswith(SUPABASE_PROXY_PREFIX):
            self.handle_supabase_proxy()
            return
        self.send_error(404)

    def do_DELETE(self):
        if self.path.startswith(SUPABASE_PROXY_PREFIX):
            self.handle_supabase_proxy()
            return
        self.send_error(404)

    def handle_launcher_control(self):
        origin = self.headers.get("Origin") or ""
        if origin and not self.is_allowed_origin(origin):
            self.send_json_error(403, "Launcher control denied.")
            return
        split = urlsplit(self.path)
        now = time.time()
        if split.path == f"{LAUNCHER_CONTROL_PREFIX}/heartbeat":
            self.server.heartbeat_seen = True
            self.server.last_heartbeat_at = now
            self.server.close_requested_at = 0
            self.send_json({"ok": True, "status": "alive"})
            return
        if split.path == f"{LAUNCHER_CONTROL_PREFIX}/closed":
            self.server.close_requested_at = now
            self.send_json({"ok": True, "status": "closing"})
            return
        self.send_json_error(404, "Launcher control path is not allowed.")

    def api_base_url(self):
        config_file = Path(getattr(self.server, "content_dir", APP_DIR)) / "supabase-config.js"
        try:
            text = config_file.read_text(encoding="utf-8")
        except OSError:
            return ""
        match = re.search(r'apiBase:\s*["\']([^"\']+)["\']', text)
        if not match:
            match = re.search(r'url:\s*["\']([^"\']+)["\']', text)
        return match.group(1).rstrip("/") if match else ""

    def is_allowed_origin(self, origin):
        if not origin:
            return True
        return bool(re.match(r"^http://(127\.0\.0\.1|localhost):\d+$", origin))

    def has_proxy_cookie(self):
        cookie = self.headers.get("Cookie") or ""
        expected = f"{PROXY_COOKIE_NAME}={self.server.proxy_token}"
        return expected in [part.strip() for part in cookie.split(";")]

    def is_allowed_proxy_path(self, path):
        return (
            path.startswith("/auth/v1/") or
            path.startswith("/rest/v1/app_state_snapshots") or
            path.startswith("/rest/v1/kaisha_companies") or
            path.startswith("/rest/v1/kaisha_company_members") or
            path.startswith("/rest/v1/kaisha_company_invitations") or
            path.startswith("/rest/v1/kaisha_company_state_snapshots") or
            path.startswith("/company/v1/create")
        )

    def handle_supabase_proxy(self):
        origin = self.headers.get("Origin") or ""
        if not self.is_allowed_origin(origin) or not self.has_proxy_cookie():
            self.send_json_error(403, "Local proxy access denied.")
            return
        base_url = self.api_base_url()
        if not base_url:
            self.send_json_error(500, "Cloud API URL is missing.")
            return
        split = urlsplit(self.path)
        upstream_path = split.path[len(SUPABASE_PROXY_PREFIX):] or "/"
        if not self.is_allowed_proxy_path(upstream_path):
            self.send_json_error(404, "Proxy path is not allowed.")
            return
        upstream_url = f"{base_url}{upstream_path}"
        if split.query:
            upstream_url = f"{upstream_url}?{split.query}"
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else None
        headers = {}
        for name in ("apikey", "authorization", "content-type", "prefer"):
            value = self.headers.get(name)
            if value:
                headers[name] = value
        headers["User-Agent"] = "KaishaRakuKeieiLocalApp/1.0"
        headers["Accept"] = "application/json"
        request = urllib.request.Request(upstream_url, data=body, headers=headers, method=self.command)
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                data = response.read()
                self.send_response(response.status)
                self.send_header("Content-Type", response.headers.get("Content-Type", "application/json"))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as error:
            data = error.read()
            self.send_response(error.code)
            self.send_header("Content-Type", error.headers.get("Content-Type", "application/json"))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
        except Exception as error:
            self.send_json_error(502, f"Supabase connection failed: {error}")

    def send_json_error(self, status, message):
        payload = ('{"message": "%s"}' % str(message).replace("\\", "\\\\").replace('"', '\\"')).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def send_json(self, payload):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)


class LocalTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


def update_cache_root():
    return INSTANCE_DIR / "updates" / "app"


def safe_relative_path(value):
    path = Path(str(value or "").replace("\\", "/"))
    if path.is_absolute() or ".." in path.parts or not str(path):
        raise ValueError("Invalid update file path.")
    return path


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def url_join(base_url, relative_path):
    return f"{base_url.rstrip('/')}/{str(relative_path).lstrip('/')}"


def fetch_json(url):
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": f"KaishaRakuKeieiUpdater/{APP_VERSION}",
        },
    )
    with urllib.request.urlopen(request, timeout=UPDATE_TIMEOUT_SECONDS) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_file(url):
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "*/*",
            "Cache-Control": "no-cache",
            "User-Agent": f"KaishaRakuKeieiUpdater/{APP_VERSION}",
        },
    )
    with urllib.request.urlopen(request, timeout=UPDATE_TIMEOUT_SECONDS) as response:
        return response.read()


def cached_update_is_valid(target_dir, files):
    if not (target_dir / ".complete").exists():
        return False
    try:
        for item in files:
            relative_path = safe_relative_path(item.get("path"))
            expected_hash = str(item.get("sha256") or "").lower()
            if not expected_hash:
                return False
            file_path = target_dir / relative_path
            if not file_path.exists() or sha256_file(file_path) != expected_hash:
                return False
    except Exception:
        return False
    return True


def install_hot_update(manifest):
    version = str(manifest.get("version") or "").strip()
    files = manifest.get("files") or []
    base_url = str(manifest.get("baseUrl") or "").strip()
    if manifest.get("app") != "kaisha-raku-keiei" or not version or not isinstance(files, list) or not base_url:
        raise ValueError("Invalid update manifest.")
    target_dir = update_cache_root() / version
    if cached_update_is_valid(target_dir, files):
        return target_dir, version, "cached"
    target_dir.mkdir(parents=True, exist_ok=True)
    for item in files:
        relative_path = safe_relative_path(item.get("path"))
        expected_hash = str(item.get("sha256") or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            raise ValueError("Invalid update file hash.")
        file_url = str(item.get("url") or "").strip() or url_join(base_url, relative_path)
        data = fetch_file(file_url)
        if sha256_bytes(data) != expected_hash:
            raise ValueError(f"Update file hash mismatch: {relative_path}")
        output_path = target_dir / relative_path
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = output_path.with_suffix(output_path.suffix + ".download")
        temp_path.write_bytes(data)
        temp_path.replace(output_path)
    if not (target_dir / "index.html").exists():
        raise ValueError("Updated app is missing index.html.")
    (target_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (target_dir / ".complete").write_text(version, encoding="utf-8")
    return target_dir, version, "downloaded"


def resolve_content_dir(page):
    if page != "index.html" or os.environ.get(UPDATE_DISABLE_ENV) == "1":
        return APP_DIR, APP_VERSION, "bundled"
    try:
        manifest = fetch_json(UPDATE_MANIFEST_URL)
        return install_hot_update(manifest)
    except Exception as error:
        print(f"Hot update skipped. Using bundled app. Reason: {error}")
        return APP_DIR, APP_VERSION, "bundled"


def free_port(start_port):
    for port in range(start_port, start_port + 50):
        with contextlib.closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind((HOST, port))
            except OSError:
                continue
            return port
    raise RuntimeError("No free local port found.")


def instance_file(page):
    name = "admin" if page == "admin.html" else "app"
    return INSTANCE_DIR / f"{name}-server-{APP_VERSION}.url"


def read_running_url(page):
    path = instance_file(page)
    try:
        url = path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""
    if not url.startswith("http://127.0.0.1:"):
        return ""
    try:
        with urllib.request.urlopen(url, timeout=0.8) as response:
            if 200 <= response.status < 400:
                return url
    except Exception:
        try:
            path.unlink()
        except OSError:
            pass
    return ""


def remember_running_url(page, url):
    try:
        INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
        instance_file(page).write_text(url, encoding="utf-8")
    except OSError:
        pass


def forget_running_url(page):
    try:
        instance_file(page).unlink()
    except OSError:
        pass


def monitor_page_close(server, page):
    while True:
        time.sleep(MONITOR_INTERVAL_SECONDS)
        close_requested_at = getattr(server, "close_requested_at", 0) or 0
        last_heartbeat_at = getattr(server, "last_heartbeat_at", 0) or 0
        if close_requested_at and last_heartbeat_at < close_requested_at and time.time() - close_requested_at >= PAGE_CLOSE_GRACE_SECONDS:
            forget_running_url(page)
            threading.Thread(target=server.shutdown, daemon=True).start()
            return


def open_url(url):
    if os.environ.get("KAISHA_RAKU_NO_BROWSER") == "1":
        print(url)
        return
    if os.environ.get("KAISHA_RAKU_SYSTEM_OPEN") == "1":
        subprocess.Popen(["/usr/bin/open", url])
    else:
        webbrowser.open(url)


def main():
    has_app = (APP_DIR / "index.html").exists()
    has_admin = (APP_DIR / "admin.html").exists()
    page = "admin.html" if "--admin" in sys.argv and has_admin else "index.html"
    if not has_app and has_admin:
        page = "admin.html"
    content_dir, content_version, content_source = resolve_content_dir(page)
    running_url = read_running_url(page)
    if running_url:
        open_url(running_url)
        return
    url_file = ""
    for arg in sys.argv:
        if arg.startswith(URL_FILE_ARG):
            url_file = arg[len(URL_FILE_ARG):]
    start_port = int(os.environ.get(START_PORT_ENV) or START_PORT)
    port = free_port(start_port)
    handler = lambda *args, **kwargs: QuietHandler(*args, directory=str(content_dir), **kwargs)
    with LocalTCPServer((HOST, port), handler) as server:
        server.proxy_token = secrets.token_urlsafe(32)
        server.content_dir = content_dir
        server.heartbeat_seen = False
        server.last_heartbeat_at = 0
        server.close_requested_at = 0
        app_url = f"http://{HOST}:{port}/index.html" if has_app else ""
        admin_url = f"http://{HOST}:{port}/admin.html" if has_admin else ""
        url = f"http://{HOST}:{port}/{page}?v={content_version}"
        remember_running_url(page, url)
        print("")
        print("会社ラク経営 is running locally.")
        print(f"Version: {content_version} ({content_source})")
        if app_url:
            print(f"App: {app_url}")
        if admin_url:
            print(f"管理后台: {admin_url}")
        print("Close this window to stop the local app.")
        print("")
        if url_file:
            Path(url_file).write_text(url, encoding="utf-8")
        if os.environ.get("KAISHA_RAKU_NO_BROWSER") != "1":
            threading.Timer(0.8, lambda: open_url(url)).start()
        threading.Thread(target=monitor_page_close, args=(server, page), daemon=True).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            time.sleep(0.1)
        finally:
            forget_running_url(page)


if __name__ == "__main__":
    main()
